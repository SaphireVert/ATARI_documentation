## Heure et Date
02.05.2023, 17h45 - 18h

## Participants
Jérôme Cosandey
Nicolas Borboën

## Lieu
EPFL, salle INN013

## Résumé
L'état du projet a été évalué. Il a été conclu que le projet avance à vitesse suffisante. Pour le moment aucun retard ou élément portant préjudice au projet n'est à signaler.

## Actions à entreprendre
Aucune action spéciale n'est à entreprendre, il faut juste finir le travail de la journée et envoyer les différents rendus, à savoir le planning initial ainsi que le rapport de TPI et le journal de travail en l'état aux experts et au chef de projet.