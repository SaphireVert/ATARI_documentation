## Date
10.04.2023 de 17h à 17h30

## Participants
Jérôme Cosandey
Nicolas Borboën

## Lieu
EPFL, salle INN013

## Résumé
Durant cette séance, l'aspect visuel de la page de détails a été examinée par le chef de projet. Il a suggéré de s'inspirer d'autres sites déjà existants de l'epfl, tels que [people](https://people.epfl.ch/)et d'utiliser des exemples de code disponibles sur la [charte graphique de l'EPFL](https://epfl-si.github.io/elements/#/) pour la réalisation du code de la page.

## Actions à entreprendre
Recommencer la page de zéro en utilisant exclusivement des éléments de la charte graphique de l'EPFL et s'inspirer de la disposition des éléments sur d'autres sites de l'EPFL.