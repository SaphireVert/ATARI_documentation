## Heure et Date
04.04.2023, 14h-15h

## Participants
Jérôme Cosandey
Nicolas Borboën

## Lieu
Appel vidéo Zoom

## Résumé

Durant cette réunion, l'état d'avancement du projet a été évalué avec le Chef de Projet.
Il a suggéré de se concentrer davantage sur la documentation durant la deuxième partie de la journée

La fonctionnalité de recherche a été présentée. L'affichage des suggestions de personnes ne lui convenait pas. Il a alors proposé une autre manière de présenter l'information.

L'accord du chef de projet a été demandé pour charger tous les utilisateurs dans le code javascript du navigateur, plutôt que faire une requête à l'API à chaque saisie de caractère. La proposition a été acceptée.

La disposition ce certains éléments de la page a également été discutée et validée. Le chef de projet en a profité pour montrer un élément de la collection de la charte graphique de l'EPFL qui va sans doute être utile pour la suite du projet : https://epfl-si.github.io/elements/#/pages/layout-demo

## Actions à entreprendre
Corriger la présentation du champ de recherche.
Mettre en place la nouvelle méthode de recherche des utilisateurs.
Faire de la documentation la seconde partie de la journée